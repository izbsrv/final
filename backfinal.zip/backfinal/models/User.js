const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true, // Уникальность логина
        index: true // Убедитесь, что индекс на поле уникальности присутствует
    },
    password: {
        type: String,
        required: true
    },
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    age: {
        type: Number,
        required: true,
        min: [0, 'Age cannot be negative'], // Проверка на возраст (положительное число)
    },
    gender: {
        type: String,
        required: true,
        enum: ['male', 'female', 'other'], // Ожидаемые значения для пола
    },
    role: {
        type: String,
        enum: ['admin', 'editor'], // Возможные роли пользователя
        default: 'editor'
    },
    twoFactorSecret: { 
        type: String 
    },
    isTwoFactorEnabled: { 
        type: Boolean, 
        default: false 
    },
}, {
    timestamps: true // Добавляет поля createdAt и updatedAt автоматически
});

module.exports = mongoose.model('User', UserSchema);
