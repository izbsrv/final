document.addEventListener('DOMContentLoaded', () => {
    // Пример получения всех элементов портфолио
    fetch('/api/portfolio')
        .then(response => response.json())
        .then(data => {
            console.log('Portfolio items:', data);
            // Отобразить элементы портфолио на странице
        })
        .catch(err => console.error('Error fetching portfolio items:', err));
});
document.getElementById('register-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const userData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        age: document.getElementById('age').value,
        gender: document.getElementById('gender').value
    };

    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });

        if (response.ok) {
            alert('User registered successfully!');
            window.location.href = 'login.html';
        } else {
            const errorData = await response.json();
            alert('Registration failed: ' + errorData.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during registration.');
    }
});
document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const loginData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value
    };

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginData)
        });

        if (response.ok) {
            const data = await response.json();
            alert('Login successful!');
            // Сохранение токена в localStorage
            localStorage.setItem('token', data.token);
            window.location.href = 'index.html';
        } else {
            const errorData = await response.json();
            alert('Login failed: ' + errorData.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during login.');
    }
});
document.addEventListener('DOMContentLoaded', async () => {
    const portfolioItemsContainer = document.getElementById('portfolio-items');

    try {
        const response = await fetch('/api/portfolio');
        const items = await response.json();

        items.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('portfolio-item');

            // Добавляем HTML для каждого элемента портфолио
            itemElement.innerHTML = `
                <h3>${item.title}</h3>
                <div class="carousel">
                    ${item.images.map(image => `<img src="${image}" alt="${item.title}">`).join('')}
                </div>
                <p>${item.description}</p>
            `;

            portfolioItemsContainer.appendChild(itemElement);
        });
    } catch (error) {
        console.error('Error fetching portfolio items:', error);
        portfolioItemsContainer.innerHTML = '<p>Failed to load portfolio items.</p>';
    }
});













document.getElementById('register-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const userData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        age: document.getElementById('age').value,
        gender: document.getElementById('gender').value
    };

    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });

        if (response.ok) {
            const data = await response.json();
            alert('User registered successfully!');
            window.location.href = data.redirectUrl;
        } else {
            const errorData = await response.json();
            alert('Registration failed: ' + errorData.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during registration.');
    }
});
document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const loginData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value
    };

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginData)
        });

        if (response.ok) {
            const data = await response.json();
            alert('Login successful!');
            window.location.href = data.redirectUrl;
        } else {
            const errorData = await response.json();
            alert('Login failed: ' + errorData.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during login.');
    }
});













document.addEventListener('DOMContentLoaded', async () => {
    const ctx = document.getElementById('financialChart').getContext('2d');

    try {
        const response = await fetch('/api/financial');
        const data = await response.json();

        const labels = data.map(item => item.date);
        const values = data.map(item => item.close);

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'AAPL Closing Prices',
                    data: values,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    fill: false,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
            }
        });
    } catch (error) {
        console.error('Error fetching financial data:', error);
    }
});


document.addEventListener('DOMContentLoaded', async () => {
    const newsContainer = document.getElementById('news-container');

    try {
        const response = await fetch('/api/news');
        const newsData = await response.json();

        newsData.forEach(article => {
            const newsItem = document.createElement('div');
            newsItem.classList.add('news-item');
            newsItem.innerHTML = `
                <h2>${article.title}</h2>
                <p>${article.description}</p>
                <a href="${article.url}" target="_blank">Read more</a>
            `;
            newsContainer.appendChild(newsItem);
        });
    } catch (error) {
        console.error('Error fetching news:', error);
        newsContainer.innerHTML = '<p>Failed to load news articles.</p>';
    }
});






document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Останавливаем отправку формы

    // Получаем данные из формы
    const loginData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value
    };

    try {
        // Отправляем запрос на сервер для входа пользователя
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginData)
        });

        if (response.ok) {
            // Если вход успешный, показываем сообщение и кнопку для перехода
            document.getElementById('login-form').style.display = 'none';
            document.getElementById('success-message').style.display = 'block';
        } else {
            // Обработка ошибки, если вход не удался
            const errorData = await response.json();
            alert('Login failed: ' + errorData.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during login.');
    }
});

// Обработка кнопки для перехода на страницу портфолио
document.getElementById('go-to-portfolio').addEventListener('click', () => {
    window.location.href = 'portfolio.html';
});
