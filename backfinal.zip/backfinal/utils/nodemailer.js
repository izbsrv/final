const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL,
        pass: process.env.EMAIL_PASSWORD,
    },
});

const sendWelcomeEmail = async (recipientEmail) => {
    const mailOptions = {
        from: process.env.EMAIL,
        to: recipientEmail,
        subject: 'Welcome to Our Platform!',
        text: 'Thank you for registering...'
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log('Welcome email sent successfully');
    } catch (err) {
        console.error('Error sending welcome email:', err);
    }
};

module.exports = {
    sendWelcomeEmail,
};
