const express = require('express');
const { getFinancialData, getNewsData } = require('../controllers/apiController');
const { authenticateUser, authorizeRole } = require('../middleware/authMiddleware');
const router = express.Router();



module.exports = router;
