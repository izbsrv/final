const PortfolioItem = require('../models/PortfolioItem');

// Получение всех элементов портфолио
const getAllItems = async (req, res) => {
    try {
        const items = await PortfolioItem.find();
        res.json(items);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch portfolio items' });
    }
};

// Создание элемента портфолио
const createItem = async (req, res) => {
    const { title, description, images } = req.body;

    try {
        const newItem = new PortfolioItem({
            title,
            description,
            images,
        });

        await newItem.save();
        res.status(201).json(newItem);
    } catch (err) {
        res.status(500).json({ error: 'Failed to create portfolio item' });
    }
};

// Обновление элемента портфолио
const updateItem = async (req, res) => {
    const { id } = req.params;
    const { title, description, images } = req.body;

    try {
        const updatedItem = await PortfolioItem.findByIdAndUpdate(
            id,
            { title, description, images },
            { new: true }
        );

        res.json(updatedItem);
    } catch (err) {
        res.status(500).json({ error: 'Failed to update portfolio item' });
    }
};

// Удаление элемента портфолио
const deleteItem = async (req, res) => {
    const { id } = req.params;

    try {
        await PortfolioItem.findByIdAndDelete(id);
        res.json({ message: 'Portfolio item deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete portfolio item' });
    }
};

module.exports = {
    getAllItems,
    createItem,
    updateItem,
    deleteItem,
};
