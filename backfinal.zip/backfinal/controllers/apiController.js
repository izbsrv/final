const axios = require('axios');

const getFinancialData = async (req, res) => {
    try {
        const response = await axios.get(`https://www.alphavantage.co/query`, {
            params: {
                function: 'TIME_SERIES_DAILY',
                symbol: 'AAPL',
                apikey: process.env.ALPHA_VANTAGE_API_KEY,
            }
        });

        // Парсим данные для удобства
        const data = response.data['Time Series (Daily)'];
        const parsedData = Object.keys(data).slice(0, 10).map(date => ({
            date,
            close: parseFloat(data[date]['4. close']),
        }));

        res.json(parsedData);
    } catch (error) {
        console.error('Error fetching financial data:', error);
        res.status(500).json({ error: 'Failed to fetch financial data' });
    }
};

const getNewsData = async (req, res) => {
    try {
        const response = await axios.get(`https://newsapi.org/v2/top-headlines`, {
            params: {
                country: 'us',
                category: 'business',
                apiKey: process.env.NEWS_API_KEY,
            }
        });

        res.json(response.data.articles);
    } catch (error) {
        console.error('Error fetching news data:', error);
        res.status(500).json({ error: 'Failed to fetch news data' });
    }
};

module.exports = {
    getFinancialData,
    getNewsData,
};
