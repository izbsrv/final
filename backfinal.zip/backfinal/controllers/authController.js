const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const nodemailer = require('../utils/nodemailer');
const speakeasy = require('speakeasy');

// Регистрация пользователя
const registerUser = async (req, res) => {
    const { username, password, firstName, lastName, age, gender } = req.body;

    try {
        // Хеширование пароля
        const hashedPassword = await bcrypt.hash(password, 10);

        // Генерация секрета для 2FA
        const twoFactorSecret = speakeasy.generateSecret({ length: 20 }).base32;

        // Создание нового пользователя
        const newUser = new User({
            username,
            password: hashedPassword,
            firstName,
            lastName,
            age,
            gender,
            twoFactorSecret,
            isTwoFactorEnabled: true,
        });

        await newUser.save();

        // Отправка приветственного письма
        await nodemailer.sendWelcomeEmail(newUser.username);

        res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
        res.status(500).json({ error: 'Registration failed' });
    }
};

// Вход пользователя
const loginUser = async (req, res) => {
    const { username, password, twoFactorCode } = req.body;

    try {
        const user = await User.findOne({ username });
        if (!user) return res.status(404).json({ error: 'User not found' });

        // Проверка пароля
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(401).json({ error: 'Invalid password' });

        // Проверка 2FA, если включено
        if (user.isTwoFactorEnabled) {
            const verified = speakeasy.totp.verify({
                secret: user.twoFactorSecret,
                encoding: 'base32',
                token: twoFactorCode,
            });

            if (!verified) return res.status(401).json({ error: 'Invalid 2FA code' });
        }

        // Генерация JWT токена
        const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
            expiresIn: '1h',
        });

        res.cookie('token', token, { httpOnly: true });
        res.json({ message: 'Login successful', token });
    } catch (err) {
        res.status(500).json({ error: 'Login failed' });
    }
};

module.exports = {
    registerUser,
    loginUser,
};
