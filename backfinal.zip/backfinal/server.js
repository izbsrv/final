const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const path = require('path'); // Подключаем path для работы с директориями
require('dotenv').config(); // Подключаем dotenv для работы с .env файлами

const User = require('./models/User'); // Модель для пользователя

const app = express();
const port = process.env.PORT || 3000;

// Middleware для парсинга JSON в теле запросов
app.use(express.json());  // Используем встроенный middleware для JSON

// Подключение к MongoDB
const dbUri = process.env.MONGODB_URI;
mongoose.connect(dbUri, {  })
    .then(() => console.log('MongoDB connected'))
    .catch(err => {
        console.error('MongoDB connection error:', err); // Логируем ошибку подключения
        process.exit(1); // Прекращаем выполнение программы при ошибке подключения
    });

// Отдача статических файлов из папки 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Роут для отдачи index.html на GET-запрос на корень
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html')); // Отдаем index.html из папки 'public'
});

// Регистрация пользователя
app.post('/api/auth/register', async (req, res) => {
    const { username, password, firstName, lastName, age, gender } = req.body;

    try {
        // Проверка, существует ли пользователь с таким логином
        const userExists = await User.findOne({ username: username });
        if (userExists) {
            return res.status(400).send({ message: 'User already exists!' });
        }

        // Хешируем пароль перед сохранением
        const hashedPassword = await bcrypt.hash(password, 10);

        // Создаем нового пользователя
        const newUser = new User({
            username,
            password: hashedPassword,
            firstName,
            lastName,
            age,
            gender
        });

        // Сохраняем пользователя в базе данных
        await newUser.save();
        console.log('User saved:', newUser); // Логирование сохраненного пользователя
        res.status(200).send({ message: 'User registered successfully!' });
    } catch (error) {
        console.error('Error during user registration:', error); // Логируем ошибку
        // Обработка ошибки уникальности пользователя
        if (error.code === 11000) {
            return res.status(400).send({ message: 'Username already taken. Please choose another.' });
        }
        res.status(500).send({ message: 'Error registering user' });
    }
});

// Вход пользователя (логин)
app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;

    console.log('Login attempt:', { username, password }); // Логируем полученные данные

    try {
        // Находим пользователя по логину
        const user = await User.findOne({ username: username });
        if (!user) {
            console.log('User not found');
            return res.status(401).send({ message: 'Invalid username or password' });
        }

        // Проверяем пароль
        const isPasswordCorrect = await bcrypt.compare(password, user.password);
        if (isPasswordCorrect) {
            console.log('Login successful for user:', user.username);
            res.status(200).send({ message: 'Login successful!' });
        } else {
            console.log('Incorrect password');
            res.status(401).send({ message: 'Invalid username or password' });
        }
    } catch (error) {
        console.error('Error during login:', error); // Логируем ошибку
        res.status(500).send({ message: 'Error logging in' });
    }
});

// Запуск сервера
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
